
<!DOCTYPE html>

<!-- Fig. 19.16: database.php -->
<!-- Querying a database and displaying the results. -->
<html>
	<head>
		<meta charset = "utf-8">
		<title>Create</title>
   
	</head>
	<body>
		<form method = "get" action = "loginnew.php">
			<h2>Create new account</h2>

			<!-- create four text boxes for user input -->
			<label>ID number:</label> 
            <input type = "text" name = "account"><br><br>
			<label>password:</label>
            <input type = "text" name = "password"><br><br>
			
			<input type = "submit" value = "submit" style="width:140px; height:50px;font-size:25px;font-weight:bolder">
		</form>
	 
	 <!--**************************
    4108040040 魯姵妤 第八次作業12/23
    4108040040 PeiYuLuThe Eighth Homework 12/23
    **************************-->
	</body>
</html>

